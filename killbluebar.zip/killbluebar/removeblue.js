$(".phoenix-banner-outer").remove();
$("body").removeClass("phoenix-skybar");

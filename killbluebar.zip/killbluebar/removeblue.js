$(".phoenix-banner-outer").remove();
